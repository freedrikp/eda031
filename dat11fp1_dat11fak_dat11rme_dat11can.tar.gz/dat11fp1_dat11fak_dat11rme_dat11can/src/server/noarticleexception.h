#ifndef NO_ART_EXCEPTION_H
#define NO_ART_EXCEPTION_H

struct NoArticleException {};

#endif
