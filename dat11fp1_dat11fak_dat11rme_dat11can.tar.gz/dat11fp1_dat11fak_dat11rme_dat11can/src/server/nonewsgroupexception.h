#ifndef NO_NGRP_EXCEPTION_H
#define NO_NGRP_EXCEPTION_H

struct NoNewsgroupException {};

#endif
